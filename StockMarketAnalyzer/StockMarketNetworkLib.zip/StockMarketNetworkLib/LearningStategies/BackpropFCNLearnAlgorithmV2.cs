﻿using StockMarketNetworkLib.Data;
using StockMarketNetworkLib.Interfaces;
using StockMarketNetworkLib.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.LearningStategies
{
    internal class BackpropFCNLearnAlgorithmV2 : ILearningStrategy<MLPNetwork>
    {

        private LearningAlgorithmConfig _config = null;
        private Random _random = null;

        internal BackpropFCNLearnAlgorithmV2(LearningAlgorithmConfig config)
        {
            _config = config;
            _random = new Random();
        }

        public void Train(MLPNetwork network, IList<DataItem<double>> data)
        {
            int epochNumber = network.TrainedEpochCount;
            double currentError = 0;
            double lastError = 0;
            bool isContinueCheckEpoch = true;
            if (_config.IsShuffleData)
                data = Shuffle(data);
            double decrementFromLearningRate = 0;
            Dictionary<int, double> errorOnEpoch = new Dictionary<int, double>();

            do
            {
                lastError = currentError;

                foreach (DataItem<double> oneItem in data)
                {

                    //int i, j, k;
                    //current neuron value

                    //check the supplied values first
                    //if the length of input and output vectors dont
                    //match with the size of first and last layers in the network,
                    //shout... :)

                    //ComputeOutput the net to begin with
                    //this generates output that we can check with 
                    //required output to compute the error
                    network.ComputeOutput(oneItem.Input.ToArray());

                    //now, lets compute the error at each neuron level

                    for (int i = 0; i < network.OutputNeuronsCount; i++)
                    {
                        //loop on each neuron in the output layer from 0 to number of neurons
                        Neuron currentNeuron = (Neuron)network.Layers.Last().Neurons[i];
                        double x = currentNeuron.LastState;
                        currentNeuron.dEdz = currentNeuron.ActivationFunction.ComputeFirstDerivative(x) * (oneItem.Output[i] - x);

                        //for (j = network.Layers.Length - 2; j >= 0; j--) //we work on each layer backwards
                        for (int j = network.Layers.Length - 2; j > 0; j--) //we work on each layer backwards
                        {
                            for (int k = 0; k < network.Layers[j].Neurons.Length; k++)
                            {
                                Neuron nrn = (Neuron)network.Layers[j].Neurons[k];
                                nrn.dEdz = nrn.LastState *
                                            (1 - nrn.LastState) * network.Layers[j + 1].Neurons[i].Inputs[k].Weight *
                                            network.Layers[j + 1].Neurons[i].dEdz;
                            }//k
                        }//j
                    }//i


                    //now work on the bias of each neuron and dendrite weights

                    //for (i = network.Layers.Length - 1; i >= 0; i--)
                    for (int i = network.Layers.Length - 1; i > 0; i--)
                    {
                        for (int j = 0; j < network.Layers[i].Neurons.Length; j++)
                        {
                            Neuron nrn = (Neuron)network.Layers[i].Neurons[j];
                            nrn.Bias = nrn.Bias + _config.LearningRate * nrn.dEdz;

                            for (int k = 0; k < nrn.Inputs.Count; k++)
                            {
                                {
                                    nrn.Inputs[k].Weight = nrn.Inputs[k].Weight +
                                                                (_config.LearningRate - decrementFromLearningRate) * network.Layers[i - 1].Neurons[k].LastState *
                                                                nrn.dEdz;

                                    //        nrn.Inputs[k].Weight = nrn.Inputs[k].Weight +   //первая версия
                                    //_config.LearningRate * network.Layers[i - 1].Neurons[k].LastState *
                                    //nrn.dEdz;
                                }
                            }//k
                        }//j
                    }//i
                }

                epochNumber++;

                currentError = 0;
                for (int i = 0; i < data.Count; i++)
                {
                    double[] realOutput = network.ComputeOutput(data[i].Input);
                    currentError += _config.ErrorFunction.Calculate(data[i].Output, realOutput);
                }
                currentError *= 1d / data.Count;

                errorOnEpoch.Add(epochNumber, currentError);


                if (epochNumber > 10 && lastError < currentError) //проверить!!!
                {
                    decrementFromLearningRate = decrementFromLearningRate + ((_config.LearningRate - decrementFromLearningRate) * (1d / epochNumber));
                }
                isContinueCheckEpoch = _config.IgnoreErrorCondition ? true : (currentError > _config.MinError && Math.Abs(currentError - lastError) > _config.MinErrorChange);
            } while (epochNumber < _config.MaxEpoches && isContinueCheckEpoch);
            network.SetErrorAndEpochCount(epochNumber, currentError);
        }

        private List<DataItem<double>> Shuffle(IList<DataItem<double>> dataItems)
        {
            List<DataItem<double>> shuffledDataItems = new List<DataItem<double>>();
            List<int> sortedIndexes = new List<int>();
            for (int i = 0; i < dataItems.Count; i++)
            {
                int newIndex = _random.Next(dataItems.Count);
                if (!sortedIndexes.Contains(newIndex))
                {
                    shuffledDataItems.Add(dataItems[newIndex]);
                    sortedIndexes.Add(newIndex);
                }
                else
                    i--;
            }
            return shuffledDataItems;
        }

    }
}
