﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib
{
    public enum MlpActivationFunction
    {
        sigmoid = 0,
        tang = 1,
    }

    public enum MlpTrainMethod
    {
        Backprop = 0
    }

}
