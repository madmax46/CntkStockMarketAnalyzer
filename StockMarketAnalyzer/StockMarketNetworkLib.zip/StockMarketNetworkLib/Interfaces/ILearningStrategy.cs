﻿using StockMarketNetworkLib.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Interfaces
{
    public interface ILearningStrategy<T>
    {
        /// <summary>
        /// Train neural network
        /// </summary>
        /// <param name="network">Neural network for training</param>
        /// <param name="inputs">Set of input vectors</param>
        /// <param name="outputs">Set of output vectors</param>
        void Train(T network,IList<DataItem<double>> data);
    }
}
