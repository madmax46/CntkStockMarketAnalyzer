﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Interfaces
{
    public interface ISynapse
    {
        INeuron FromNeuron { get; set; }
        INeuron ToNeuron { get; set; }
        double Weight { get; set; }
    }
}
