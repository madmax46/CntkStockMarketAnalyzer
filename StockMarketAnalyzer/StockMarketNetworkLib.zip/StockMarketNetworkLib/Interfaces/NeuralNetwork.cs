﻿using StockMarketNetworkLib.Data;
using StockMarketNetworkLib.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Interfaces
{
    public interface INeuralNetwork
    {
        int[] LayersModel { get; }
        MlpActivationFunction ActivationFunction { get; }

        /// <summary>
        /// Compute output vector by input vector
        /// </summary>
        /// <param name="inputVector">Input vector (double[])</param>
        /// <returns>Output vector (double[])</returns>
        double[] ComputeOutput(double[] inputVector);

        LearningAlgorithmConfig LearnAlgorithmConfig { get; }

        int TrainedEpochCount { get; }

        double TrainLastEpochError { get;  }

        /// <summary>
        /// Train network with given inputs and outputs
        /// </summary>
        /// <param name="inputs">Set of input vectors</param>
        /// <param name="outputs">Set if output vectors</param>
        void Train(IList<DataItem<double>> data);

        /// <summary>
        /// Установление функции активации для тренировки сети
        /// </summary>
        /// <param name="activationFunction"></param>
        /// <param name="a"></param>
        /// <param name="s"></param>
        void SetActivationFunction(MlpActivationFunction activationFunction, double alpha);
        void SetTrainMethod(MlpTrainMethod trainMethod, LearningAlgorithmConfig config);

        void SetTrainMethod(MlpTrainMethod trainMethod);

        bool Save(string path);

        void SetLayerSizes(int[] layerSize);

    }
}
