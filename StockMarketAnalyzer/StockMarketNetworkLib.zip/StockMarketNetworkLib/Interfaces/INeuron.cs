﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Interfaces
{
    public interface INeuron
    {


        /// <summary>
        /// Input connections of the neuron.
        /// </summary>
         List<ISynapse> Inputs { get; set; }

        /// <summary>
        /// Output connections of the neuron.
        /// </summary>
         List<ISynapse> Outputs { get; set; }



        /// <summary>
        /// Weights of the neuron
        /// </summary>
        //double[] Weights { get; }

        /// <summary>
        /// Offset/bias of neuron (default is 0)
        /// </summary>
        double Bias { get; set; }

        /// <summary>
        /// Compute NET of the neuron by input vector
        /// </summary>
        /// <param name="inputVector">Input vector (must be the same dimension as was set in SetDimension)</param>
        /// <returns>NET of neuron</returns>
        //double NET(double[] inputVector);
        double NET();

        /// <summary>
        /// Compute state of neuron
        /// </summary>
        /// <param name="inputVector">Input vector (must be the same dimension as was set in SetDimension)</param>
        /// <returns>State of neuron</returns>
        double Activate(double[] inputVector);
        double Activate(double input);


        /// <summary>
        /// Last calculated state in Activate
        /// </summary>
        double LastState { get; set; }

        /// <summary>
        /// Last calculated NET in NET
        /// </summary>
        double LastNET { get; set; }

        IFunction ActivationFunction { get; set; }

        double dEdz { get; set; }
    }
}
