﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Xml;
using StockMarketNetworkLib.Models;

namespace StockMarketNetworkLib.SaveNetwork
{
    [Serializable]
     public class SaveParamsMLP
    {
        public string Name { get; set; }
        public int[] LayerSizes { get; set; }

        public List<double> NeuronsBiases { get; set; }

        public List<double> Weights { get; set; }

        public SaveParamsMLP()
        {
            LayerSizes = new int[0];
            NeuronsBiases = new List<double>();
            Weights = new List<double>();
        }
    }

}

