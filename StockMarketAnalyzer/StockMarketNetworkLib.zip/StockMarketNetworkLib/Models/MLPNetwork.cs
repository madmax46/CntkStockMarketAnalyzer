﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StockMarketNetworkLib.Data;
using StockMarketNetworkLib.Interfaces;
using StockMarketNetworkLib.ActivationFunc;
using StockMarketNetworkLib.LearningStategies;
using StockMarketNetworkLib.Enums;
using System.Xml.Serialization;
using StockMarketNetworkLib.SaveNetwork;

namespace StockMarketNetworkLib.Models
{
    public class MLPNetwork : IMultilayerNeuralNetwork
    {
        public ILayer[] Layers { get; set; }
        public int[] LayersModel {get; private set;}

        public int OutputNeuronsCount { get { return Layers != null && Layers.Any() ? Layers.Last().Neurons.Length : 0; } }
        public int InputNeuronsCount { get { return Layers != null && Layers.Any() ? Layers.First().Neurons.Length : 0; } }

        public int TrainedEpochCount { get; private set; }

        public double TrainLastEpochError { get; private set; }

        public LearningAlgorithmConfig LearnAlgorithmConfig { get; private set; }

        public MlpActivationFunction ActivationFunction { get; private set; }


        private IFunction activationFunc;

        private ILearningStrategy<MLPNetwork> learningStrategy;

        public MLPNetwork()
        {
            LearnAlgorithmConfig = new LearningAlgorithmConfig();
            ActivationFunction = MlpActivationFunction.sigmoid;
            activationFunc = new SigmoidFunction(0.5);
             learningStrategy = new BackpropFCNLearnAlgorithmV2(LearnAlgorithmConfig);
            //learningStrategy = new BackpropagationFCNLearningAlgorithm(LearnAlgorithmConfig);
            Layers = new ILayer[0];
        }

        public void SetActivationFunction(MlpActivationFunction activationFunction_, double alpha)
        {
            ActivationFunction = activationFunction_;
            switch (activationFunction_)
            {
                case MlpActivationFunction.sigmoid: activationFunc = new SigmoidFunction(alpha); break;
                case MlpActivationFunction.tang: activationFunc = new HyperbolicTangensFunction(alpha); break;
            }
        }

        public void SetTrainMethod(MlpTrainMethod trainMethod, LearningAlgorithmConfig learnConfig)
        {
            LearnAlgorithmConfig = learnConfig;
            SetTrainMethod(trainMethod);
        }
        public void SetTrainMethod(MlpTrainMethod trainMethod)
        {
            switch (trainMethod)
            {
               // case MlpTrainMethod.Backprop: learningStrategy = new BackpropagationFCNLearningAlgorithm(LearnAlgorithmConfig); break;
                case MlpTrainMethod.Backprop: learningStrategy = new BackpropFCNLearnAlgorithmV2(LearnAlgorithmConfig); break;
                    //case MlpTrainMethod.Backprop: learningStrategy = new temp2(LearnAlgorithmConfig); break;

            }
        }

        public double[] ComputeOutput(double[] inputVector)
        {

            if (inputVector.Length != InputNeuronsCount)
                throw new Exception("Не сходится количество параметров входного вектора и количество входных нейронов");


            foreach (Layer oneLayer in Layers)
            {
                foreach (Neuron neuron in oneLayer.Neurons)
                {
                    neuron.LastNET = 0;
                    neuron.LastState = 0;
                }
            }

            foreach (Layer oneLayer in Layers)
            {
                if (oneLayer.Type == LyaerType.Input)
                {
                    for (int i = 0; i < inputVector.Length; i++)
                    {
                        oneLayer.Neurons[i].LastState = inputVector[i];
                    }
                    continue;
                }

                if (!oneLayer.Neurons.Any() || !oneLayer.Neurons[0].Inputs.Any())
                    throw new Exception("нету связей между нейронами или нету ");


                foreach (Neuron oneNeuron in oneLayer.Neurons)
                {
                    oneNeuron.Activate(oneNeuron.NET());
                }
            }
            var computeVal = Layers.Last().GetOutput();
            computeVal = Softmax(computeVal);
            return computeVal;

        }

        private static double[] Softmax(double[] hoSums)
        {
            // determine max
            double max = hoSums.Max();

            // determine scaling factor (sum of exp(eachval - max)
            double scale = hoSums.Sum(t => Math.Exp(t - max));

            var result = hoSums.Select(t => Math.Exp(t - max) / scale);
            return result.ToArray();
        }

        public bool Save(string path)
        {
            SaveParamsMLP netToSave = CreateSaveParams();
            XmlSerializer formatter = new XmlSerializer(typeof(SaveParamsMLP));

            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                fs.SetLength(0);
                formatter.Serialize(fs, netToSave);
            }

            return true;
        }

        public static MLPNetwork LoadFromFile(string path)
        {
            XmlSerializer formatter = new XmlSerializer(typeof(SaveParamsMLP));
            SaveParamsMLP loadedNet = new SaveParamsMLP();
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                loadedNet = (SaveParamsMLP)formatter.Deserialize(fs);
            }
            MLPNetwork mLPNetwork = new MLPNetwork();
            mLPNetwork.SetLayerSizes(loadedNet.LayerSizes);
            mLPNetwork.LoadBiases(loadedNet.NeuronsBiases);
            mLPNetwork.LoadSynapsesWeights(loadedNet.Weights);
            return mLPNetwork;
        }

        private SaveParamsMLP CreateSaveParams()
        {
            List<double> biases = new List<double>();
            for (int i = 1; i < Layers.Length; i++)
            {
                double[] oneLayerBiases = Layers[i].Neurons.Select(r => r.Bias).ToArray();
                biases.AddRange(oneLayerBiases);
            }
            List<double> weights = new List<double>();

            foreach (Layer oneLayer in Layers)
            {
                foreach (Neuron oneNeuron in oneLayer.Neurons)
                {
                    weights.AddRange(oneNeuron.GetInputSynapsesWeigts());
                }
            }

            SaveParamsMLP netToSave = new SaveParamsMLP()
            {
                Name = "Multilayer perceptron",
                LayerSizes = LayersModel,
                NeuronsBiases = biases,
                Weights = weights
            };
            return netToSave;
        }

        public void Train(IList<DataItem<double>> data)
        {
            learningStrategy.Train(this, data);
        }

        public void SetLayerSizes(int[] layerSize)
        {

            if (layerSize.Length < 3)
                throw new Exception("Минимальное количество слоев 3: 1 слой - вход, 1 слой - выход и 1 скрытый слой");

            foreach(int nCount in layerSize)
            {
                if(nCount<=0)
                    throw new Exception($"Минимальное количество неронов в слое - 1. Проверьте слой {nCount}");

            }
            LayersModel = layerSize;

            Random random = new Random();
            Layers = new Layer[layerSize.Length];
            for (int i = 0; i < layerSize.Length; i++)
            {
                Neuron[] neurons = new Neuron[layerSize[i]];

                for (int j = 0; j < neurons.Length; j++)
                {
                    neurons[j] = new Neuron();
                    neurons[j].ActivationFunction = activationFunc;
                    neurons[j].Inputs = new List<ISynapse>();

                    if (i != 0)
                    {
                        neurons[j].Inputs = new List<ISynapse>();
                        if (i != layerSize.Length - 1)
                            neurons[j].Outputs = new List<ISynapse>();
                        foreach (var Neuron in Layers[i - 1].Neurons)
                        {
                            Synapse synapse = new Synapse(Neuron, neurons[j], random.NextDouble());
                            neurons[j].Inputs.Add(synapse);
                            Neuron.Outputs.Add(synapse);
                        }
                    }
                    else
                    {
                        neurons[j].Outputs = new List<ISynapse>();
                    }

                }

                if (i == 0)
                {
                    Layers[i] = new Layer(neurons, LyaerType.Input);
                }
                else if (i == layerSize.Length - 1)
                {
                    Layers[i] = new Layer(neurons, LyaerType.Output);

                }
                else
                {
                    Layers[i] = new Layer(neurons, LyaerType.Hidden);

                }
            }
        }


        internal void SetErrorAndEpochCount(int epochCount, double error)
        {
            TrainedEpochCount = epochCount;
            TrainLastEpochError = error;
        }


        private void LoadBiases(List<double> biases)
        {
            int curBiasIndex = 0;
            foreach(Layer oneLayer in Layers)
            {
                if (oneLayer.Type == LyaerType.Input)
                    continue;

                foreach (var oneNeuron in oneLayer.Neurons)
                {
                    oneNeuron.Bias = biases[curBiasIndex++];                 
                }
            }
            if (curBiasIndex != biases.Count)
                throw new Exception("Не сходится количество нейронов сети и количество bias");
        }

        private void LoadSynapsesWeights(List<double> weights)
        {
            int curSynapseIndex = 0;
            foreach (Layer oneLayer in Layers)
            {
                if (oneLayer.Type == LyaerType.Input)
                    continue;

                foreach (var oneNeuron in oneLayer.Neurons)
                {
                    foreach (var oneInput in oneNeuron.Inputs)
                    {
                        oneInput.Weight = weights[curSynapseIndex++];
                    }
                }
            }
            if (curSynapseIndex != weights.Count)
                throw new Exception("Не сходится количество синапсисов сети и количество сохраненных синапсисов");

        }
    }
}
