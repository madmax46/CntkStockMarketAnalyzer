﻿using StockMarketNetworkLib.Enums;
using StockMarketNetworkLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Models
{
    [Serializable]
    public class Layer : ILayer
    {
        public LyaerType Type { get; set; }

        public double[] LastOutput { get; }

        public INeuron[] Neurons { get; }

        public int InputDimension { get; }

        //public double[] Compute(double[] inputVector)
        //{
        //    throw new NotImplementedException();
        //}
        public double[] GetOutput()
        {
            return Neurons.Select(r => r.LastState).ToArray();
        }
        public Layer ()
        {
            Neurons = new INeuron[0];
            Type = LyaerType.Hidden;
        }
        public Layer(INeuron[] neurons)
        {
            Neurons = neurons;
        }
        public Layer(INeuron[] neurons, LyaerType type)
        {
            Neurons = neurons;
            Type = type;
        }
    }
}
