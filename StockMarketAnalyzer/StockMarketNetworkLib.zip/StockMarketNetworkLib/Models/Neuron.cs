﻿using StockMarketNetworkLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Models
{
    [Serializable]
    public class Neuron : INeuron
    {

        public Neuron()
        {
            Bias = 0;
            dEdz = 0;
            LastNET = 0;
        }


        /// <summary>
        /// Input connections of the neuron.
        /// </summary>
        public List<ISynapse> Inputs { get; set; }

        /// <summary>
        /// Output connections of the neuron.
        /// </summary>
        public List<ISynapse> Outputs { get; set; }

        public List<double> GetInputSynapsesWeigts()
        {
            if (Inputs == null || !Inputs.Any())
                return new List<double>();
            return Inputs.Select(r => r.Weight).ToList();
        }

        //public double[] Weights { get; set; }

        public double Bias { get; set; }
        public double LastState { get; set; }
        public double LastNET { get; set; }


        public IFunction ActivationFunction { get; set; }
        public double dEdz { get; set; }

        public double Activate(double[] inputVector)
        {

            return 0;
            //ActivationFunction.Compute()
        }

        public double Activate(double input)
        {
            LastState = ActivationFunction.Compute(input);
            return LastState;
        }

        public double NET()
        {
            double calcVal = Inputs.Sum(r=>r.Weight * r.FromNeuron.LastState) + Bias;
            //double calcVal = Inputs.Sum(r => r.Weight * r.FromNeuron.LastState);

            LastNET = calcVal;
            return calcVal;
        }
    }
}
