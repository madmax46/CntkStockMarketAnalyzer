﻿using StockMarketNetworkLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Models
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class Synapse : ISynapse
    {
        public INeuron FromNeuron { get; set; }
        public INeuron ToNeuron { get; set; }

        /// <summary>
        /// Weight of the connection.
        /// </summary>
        public double Weight { get; set; }

        /// <summary>
        /// Weight that connection had in previous itteration.
        /// Used in training process.
        /// </summary>

        public Synapse(INeuron fromNeuraon, INeuron toNeuron, double weight)
        {
            FromNeuron = fromNeuraon;
            ToNeuron = toNeuron;

            Weight = weight;
        }

        public Synapse(INeuron fromNeuraon, INeuron toNeuron)
        {
            FromNeuron = fromNeuraon;
            ToNeuron = toNeuron;

            var tmpRandom = new Random();
            Weight = tmpRandom.NextDouble();
        }


    }

}
