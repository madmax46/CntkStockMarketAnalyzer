﻿using StockMarketNetworkLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StockMarketNetworkLib.Metrics;

namespace StockMarketNetworkLib.Models
{
    public class LearningAlgorithmConfig
    {
        public LearningAlgorithmConfig()
        {
            BatchSize = 1;
            //MaxEpoches = int.MaxValue;
            MaxEpoches = 200;

            // ErrorFunction =  new Loglikelihood();
            ErrorFunction = new HalfSquaredEuclidianDistance();
            MinError = 0.0001;
            MinErrorChange = 0.00001;
            RegularizationFactor = 0.1;
            LearningRate = 0.6;
            IgnoreErrorCondition = true;
            IsShuffleData = false;
        }

        public double LearningRate { get; set; }

        public bool IgnoreErrorCondition { get; set; }
       
        /// <summary>
        /// Size of the butch. -1 means fullbutch size. 
        /// </summary>
        public int BatchSize { get; set; }

        public double RegularizationFactor { get; set; }

        public int MaxEpoches { get; set; }

        /// <summary>
        /// If cumulative error for all training examples is less then MinError, then algorithm stops 
        /// </summary>
        public double MinError { get; set; }

        /// <summary>
        /// If cumulative error change for all training examples is less then MinErrorChange, then algorithm stops 
        /// </summary>
        public double MinErrorChange { get; set; }

        /// <summary>
        /// Function to minimize
        /// </summary>
        public IMetrics<double> ErrorFunction { get; }

        public bool IsShuffleData { get; private set; }

    }
}
