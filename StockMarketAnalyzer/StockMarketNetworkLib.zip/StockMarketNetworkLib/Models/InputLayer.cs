﻿using StockMarketNetworkLib.Enums;
using StockMarketNetworkLib.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Models
{
    class InputLayer : ILayer
    {


        public double[] LastOutput => throw new NotImplementedException();

        public INeuron[] Neurons { get; set; }

        public void InitNeurons(double[] inputVector)
        {
        }
        public int InputDimension { get; set; }

        public double[] GetOutput()
        {
            return Neurons.Select(r => r.LastState).ToArray();
        }
    }
}
