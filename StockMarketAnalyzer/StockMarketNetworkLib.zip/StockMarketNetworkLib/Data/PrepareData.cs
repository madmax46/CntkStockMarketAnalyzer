﻿using StockMarketNetworkLib.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockMarketNetworkLib.Data
{
    public static class PrepareData
    {
        private static string[] authorizedColumNameToParse = new string[] { "DATE", "TIME", "OPEN", "HIGH", "LOW", "CLOSE" };

        public static double[] asd()
        {
            return new double[0];
        }

        private static double[] MinMaxNormalize(double[] values)
        {
            double min = values.Min();
            double max = values.Max();
            List<double> newValues = new List<double>();
            foreach (double oneVal in values)
            {
                double newItem = (oneVal - min) / (max - min);
                newValues.Add(newItem);
            }
            return newValues.ToArray();
        }

        private static double[] ZScoreNormalize(double[] values)
        {
            List<double> newValues = new List<double>();

            double sum = values.Sum();
            double mean = sum / values.Length;

            double bigSum = values.Sum(r => Math.Pow(r - mean, 2));
            double stdDev = Math.Sqrt(bigSum / (values.Length - 1));

            foreach (double value in values)
            {
                double newItem = (value - mean) / stdDev;
                newValues.Add(newItem);
            }
            return newValues.ToArray();
        }


        public static List<DataItem<double>> CreateDataForClassification(double[] values, int window, int forecast)
        {
            //var normalizedData = ZScoreNormalize(values);
            var normalizedData = MinMaxNormalize(values);

            //var normalizedData = values;

            List<DataItem<double>> dataItems = new List<DataItem<double>>();

            for (int i = 0; i < values.Length; i++)
            {
                double[] inputValues = new double[window];
                if (i + window + forecast >= values.Length)
                    break;
                double y_i = normalizedData[i + window + forecast];
                Array.Copy(normalizedData, i, inputValues, 0, window);
                double last_close = inputValues[window - 1];
                double next_close = y_i;

                double[] outputClass = new double[2];

                if (last_close < next_close)
                {
                    outputClass[0] = 1;
                    outputClass[1] = 0;
                }
                else
                {
                    outputClass[0] = 0;
                    outputClass[1] = 1;
                }

                dataItems.Add(new DataItem<double>(inputValues, outputClass));
            }

            return dataItems;
        }

        public static DataTable ParseDataToTable(string path, bool isfirstRowHead, string columnSeparator = ";")
        {
            string pathOnly = Path.GetDirectoryName(path);
            if (string.IsNullOrEmpty(pathOnly))
            {
                pathOnly = Environment.CurrentDirectory;
            }
            string fileName = Path.GetFileName(path);
            string pathToSchema = Path.Combine(pathOnly, "schema.ini");
            using (FileStream stream = File.Open(pathToSchema, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.WriteLine(string.Format("[{0}]", fileName));
                    writer.WriteLine($"Format=Delimited({columnSeparator})");
                    writer.WriteLine("TextDelimiter='");
                    writer.WriteLine($"ColNameHeader={isfirstRowHead}");
                }
            }
            DataTable dataTable = new DataTable();


            string sql = @"SELECT * FROM [" + fileName + "]";

            using (OleDbConnection connection = new OleDbConnection(
                      @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + pathOnly +
                      ";Extended Properties=\"Text;HDR=" + isfirstRowHead + ";\""))
            using (OleDbCommand command = new OleDbCommand(sql, connection))
            using (OleDbDataAdapter adapter = new OleDbDataAdapter(command))
            {
                //dataTable.Locale = CultureInfo.CurrentCulture;
                adapter.Fill(dataTable);
            }
            if (File.Exists(pathToSchema))
                File.Delete(pathToSchema);
            return dataTable;

        }

        public static DataTable ClearWrongColumns(DataTable inputTable, List<int> indexesToRemove = null)
        {
            DataTable outputTable = inputTable.Copy();
            List<DataColumn> colToDelete = new List<DataColumn>();
            if (inputTable.Columns.Count == 1)
                throw new Exception("Только один столбец в данных");
            int indexCol = 0;
            foreach (DataColumn oneCol in outputTable.Columns)
            {
                if (indexesToRemove != null && indexesToRemove.Contains(indexCol++))
                {
                    colToDelete.Add(oneCol);
                }
                else
                if (!authorizedColumNameToParse.Any(r => oneCol.ColumnName.Contains(r)))
                {
                    colToDelete.Add(oneCol);
                }
                indexCol++;
            }
            foreach (var oneCol in colToDelete)
            {
                outputTable.Columns.Remove(oneCol);
            }

            return outputTable;

        }

        public static double[] ColumnToArray(DataTable inputTable, int colIndex, CultureInfo culture = null)
        {
            if (culture == null)
                culture = CultureInfo.CurrentCulture;

            double[] newValues = new double[inputTable.Rows.Count];
            newValues = inputTable.AsEnumerable().Select(r => Convert.ToDouble(r[colIndex], culture)).ToArray();
            return newValues;
        }
    }
}
